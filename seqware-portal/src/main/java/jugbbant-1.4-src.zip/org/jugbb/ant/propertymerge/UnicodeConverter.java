package org.jugbb.ant.propertymerge;

public class UnicodeConverter {

	private static final String HEX_DIGITS = "0123456789ABCDEF"; 
	
	private static char getHexDigit(int decimal) {
		return HEX_DIGITS.charAt(decimal & 0x0f);
	}
	
	private static String hexValue(int value) {
		StringBuilder sb = new StringBuilder();
		sb.append(getHexDigit(value >>> 12));
		sb.append(getHexDigit(value >>> 8));
		sb.append(getHexDigit(value >>> 4));
		sb.append(getHexDigit(value));
		return sb.toString();
	}
	
	public static String getUnicodeLiteral(char c) {
		if (c == 10) return "\\n";
		if (c == 13) return "\\r";
		if (c == 92) return "\\\\";
		if (c == 34) return "\\\"";
		if (c < 32 || c > 126) return "\\u" + hexValue(c);
		return String.valueOf(c);
	}
	
	public static String getStringWithUnicodeLiterals(String source) {
		StringBuilder sb = new StringBuilder(source.length() * 5);
		for (int i = 0; i < source.length(); i++) {
			sb.append(getUnicodeLiteral(source.charAt(i)));
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		String test = "Jan hat eine höhere Mücke und hält ein Maß";
		System.out.println(test);
		System.out.println(getStringWithUnicodeLiterals(test));
	}
	
}
