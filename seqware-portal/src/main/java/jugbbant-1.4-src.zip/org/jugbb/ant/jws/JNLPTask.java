package org.jugbb.ant.jws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.StringTokenizer;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

public class JNLPTask extends Task {
	
	private String jnlpFileName;
	private String jnlpVersion = "6.0+";
	private String codebase;
	private String title;
	private String vendor;
	private String homepage;
	private String iconHref;
	private String offlineAllowed = "true";
	private String description;
	private String createDesktopShortcut;
	private String createMenuEntry;
	private String subMenuName;
	private String associateWithFileExtensions;
	private String associateWithMimeType;
	private String updateCheck = "timeout";
	private String updatePolicy = "always";
	private String javaVersion = "1.6+";
	private String javaMaxHeapSize;
	private String folderWithSignedJars;
	private String mainClass;
	private String applicationArguments;
	
	public String getJnlpFileName() {
		return jnlpFileName;
	}
	
	public void setJnlpFileName(String jnlpFileName) {
		this.jnlpFileName = jnlpFileName;
	}
	
	public String getJnlpVersion() {
		return jnlpVersion;
	}
	
	public void setJnlpVersion(String jnlpVersion) {
		this.jnlpVersion = jnlpVersion;
	}
	
	public String getCodebase() {
		return codebase;
	}
	
	public void setCodebase(String codebase) {
		this.codebase = codebase;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String titel) {
		this.title = titel;
	}
	
	public String getVendor() {
		return vendor;
	}
	
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	
	public String getHomepage() {
		return homepage;
	}
	
	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}
	
	public String getIconHref() {
		return iconHref;
	}
	
	public void setIconHref(String iconHref) {
		this.iconHref = iconHref;
	}
	
	public String getOfflineAllowed() {
		return offlineAllowed;
	}
	
	public void setOfflineAllowed(String offlineAllowed) {
		this.offlineAllowed = offlineAllowed;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getCreateDesktopShortcut() {
		return createDesktopShortcut;
	}
	
	public void setCreateDesktopShortcut(String createDesktopShortcut) {
		this.createDesktopShortcut = createDesktopShortcut;
	}
	
	public String getCreateMenuEntry() {
		return createMenuEntry;
	}
	
	public void setCreateMenuEntry(String createMenuEntry) {
		this.createMenuEntry = createMenuEntry;
	}
	
	public String getSubMenuName() {
		return subMenuName;
	}
	
	public void setSubMenuName(String subMenuName) {
		this.subMenuName = subMenuName;
	}
	
	public String getAssociateWithFileExtensions() {
		return associateWithFileExtensions;
	}
	
	public void setAssociateWithFileExtensions(String associateWithFileExtension) {
		this.associateWithFileExtensions = associateWithFileExtension;
	}
	
	public String getAssociateWithMimeType() {
		return associateWithMimeType;
	}
	
	public void setAssociateWithMimeType(String associateWithMimeType) {
		this.associateWithMimeType = associateWithMimeType;
	}
	
	public String getUpdateCheck() {
		return updateCheck;
	}
	
	public void setUpdateCheck(String updateCheck) {
		this.updateCheck = updateCheck;
	}
	
	public String getUpdatePolicy() {
		return updatePolicy;
	}
	
	public void setUpdatePolicy(String updatePolicy) {
		this.updatePolicy = updatePolicy;
	}
	
	public String getJavaVersion() {
		return javaVersion;
	}
	
	public void setJavaVersion(String javaVersion) {
		this.javaVersion = javaVersion;
	}
	
	public String getJavaMaxHeapSize() {
		return javaMaxHeapSize;
	}
	
	public void setJavaMaxHeapSize(String javaMaxHeapSize) {
		this.javaMaxHeapSize = javaMaxHeapSize;
	}
	
	public String getFolderWithSignedJars() {
		return folderWithSignedJars;
	}
	
	public void setFolderWithSignedJars(String folderWithSignedJars) {
		this.folderWithSignedJars = folderWithSignedJars;
	}
	
	public String getMainClass() {
		return mainClass;
	}

	public void setMainClass(String mainClass) {
		this.mainClass = mainClass;
	}
	
	public String getApplicationArguments() {
		return applicationArguments;
	}
	
	public void setApplicationArguments(String applicationArguments) {
		this.applicationArguments = applicationArguments;
	}
	
	@Override
	public void execute() throws BuildException {
		if (title == null) {
			throw new BuildException("Attribute title cannot be null");
		}
		if (codebase == null) {
			throw new BuildException("Attribute codebase cannot be null");
		}
		if (folderWithSignedJars == null) {
			throw new BuildException("Attribute folderWithSignedJars cannot be null");
		}
		if (jnlpFileName == null) {
			throw new BuildException("Attribute jnlpFileName cannot be null");
		}
		File baseDir = new File(folderWithSignedJars);
		if (baseDir.exists() == false || baseDir.isDirectory() == false) {
			throw new BuildException("folderWithSignedJars must exists and must be a directory");
		}
		File jnlpFile = new File(folderWithSignedJars, jnlpFileName);
		log("create jnlp file: " + jnlpFile.getAbsolutePath() + " with codebase: " + codebase);
		Writer writer = null;
		try {
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(jnlpFile, false), "UTF-8"));
			writeJNLP(writer);
		} catch (IOException e) {
			throw new BuildException("write jnlp file failed: " + e.getMessage(), e);
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (Exception e) {
					throw new BuildException("close jnlp file failed: " + e.getMessage(), e);
				}
			}
		}
	}
	
	private void writeJNLP(Writer writer) throws IOException {
		writer.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
		// jnlp
		writer.write("<jnlp spec=\"");
		writer.write(jnlpVersion);
		writer.write("\" codebase=\"");
		writer.write(codebase);
		writer.write("\" href=\"");
		writer.write(jnlpFileName);
		writer.write("\">\n\n");
		// information
		writeInformation(writer);
		writeUpdate(writer);
		writeSecurity(writer);
		writeResources(writer);
		writeApplicationDesc(writer);
		writer.write("</jnlp>");
	}
	
	private void writeInformation(Writer writer) throws IOException {
		writer.write("<information>\n");
		writer.write("<title>" + title + "</title>\n");
		writer.write("<vendor>" + vendor + "</vendor>\n");
		if (homepage != null) {
			writer.write("<homepage href=\"" + homepage + "\"/>\n");
		}
		writer.write("<description kind=\"short\">" + description + "</description>\n");
		writer.write("<icon href=\"" + iconHref + "\"/>\n");
		if (Boolean.parseBoolean(offlineAllowed)) {
			writer.write("<offline-allowed/>\n");
		}
		boolean createDesktopShortCut = Boolean.parseBoolean(createDesktopShortcut);
		boolean createMenuEntry = Boolean.parseBoolean(this.createMenuEntry);
		if (createDesktopShortCut || createMenuEntry) {
			writer.write("<shortcut online=\"true\">\n");
			if (createDesktopShortCut) {
				writer.write("<desktop/>\n");
			}
			if (createMenuEntry) {
				writer.write("<menu/>\n");
			}
			writer.write("</shortcut>\n");
		}
		if (associateWithFileExtensions != null || associateWithMimeType != null) {
			writer.write("<association");
		    if (associateWithFileExtensions != null) {
				writer.write(" extensions=\""+ associateWithFileExtensions + "\"");
		    }
		    if (associateWithMimeType != null) {
				writer.write(" mime-type=\""+ associateWithMimeType + "\"");
		    }
		    writer.write(" />\n");
		}
		writer.write("</information>\n\n");
	}
	
	private void writeUpdate(Writer writer) throws IOException {
		writer.write("<update check=\""+updateCheck+"\" policy=\""+updatePolicy+"\" />\n\n");
	}

	private void writeSecurity(Writer writer) throws IOException {
		writer.write("<security>\n");
		writer.write("<all-permissions/>\n");
		writer.write("</security>\n\n");
	}

	private void writeResources(Writer writer) throws IOException {
		writer.write("<resources>\n");
		writer.write("<j2se version=\""+javaVersion+"\"");
		if (javaMaxHeapSize != null) {
			writer.write(" max-heap-size=\""+javaMaxHeapSize+"\"");
		}
		writer.write("/>\n");
		File baseDir = new File(folderWithSignedJars);
		File[] jars = baseDir.listFiles();
		boolean jarsAdded = false;
		if (jars != null && jars.length > 0) {
			for (File jarFile : jars) {
				if (jarFile.getName().toLowerCase().endsWith(".jar")) {
					writer.write("<jar href=\""+jarFile.getName()+"\"/>\n");
					jarsAdded = true;
				}
			}
		}
		if (jarsAdded == false) {
			throw new BuildException("There are no jar-files to add as resource");
		}
		writer.write("</resources>\n\n");
	}
	
	private void writeApplicationDesc(Writer writer) throws IOException {
		writer.write("<application-desc main-class=\""+mainClass+"\">\n");
		if (applicationArguments != null) {
			StringTokenizer st = new StringTokenizer(applicationArguments, " ");
			while (st.hasMoreTokens()) {
				writer.write("<argument>" + st.nextToken() + "</argument>\n");
			}
		}
		writer.write("</application-desc>\n\n");
	}

}
