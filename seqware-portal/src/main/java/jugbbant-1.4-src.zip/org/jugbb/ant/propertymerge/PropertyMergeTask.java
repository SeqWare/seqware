package org.jugbb.ant.propertymerge;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.Iterator;
import java.util.Properties;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.LogLevel;

public class PropertyMergeTask extends Task {
	
	private String inputPropertyFile;
	private String inputPropertyFileEncoding = "UTF-8";
	private Properties inputProperties = new Properties();
	private String mergePropertyFile;
	private String mergePropertyFileEncoding = null;
	private Properties mergeProperties = new Properties();
	private String outputPropertyFile;
	private String outputFileOSType = "UNIX";
	private String outputPropertyFileEncoding = null;
	private boolean native2Ascii = true;

	@SuppressWarnings("unchecked")
	@Override
	public void execute() throws BuildException {
		if (inputPropertyFile == null || inputPropertyFile.length() == 0) {
			throw new BuildException("inputPropertyFile attribute cannot be null or empty");
		}
		File inputFile = new File(inputPropertyFile);
		if (inputFile.exists() == false || inputFile.canRead() == false) {
			throw new BuildException("inputPropertyFile " + inputFile.getAbsolutePath() + " does not exists or cannot be read");
		} else if (inputFile.length() == 0) {
			log("inputPropertyFile is empty", LogLevel.WARN.getLevel());
		}
		try {
			log("Load input properties " + inputFile.getAbsolutePath());
			Reader reader = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), inputPropertyFileEncoding));
			if (reader != null) {
				inputProperties.load(reader);
				reader.close();
			}
			log("Input properties loaded with " + inputProperties.size() + " entries");
		} catch (Exception e) {
			throw new BuildException("load inputProperties failed: " + e.getMessage(), e);
		}
		if (mergePropertyFile == null || mergePropertyFile.length() == 0) {
			throw new BuildException("mergePropertyFile attribute cannot be null or empty");
		}
		File mergeFile = new File(mergePropertyFile);
		if (mergeFile.exists() == false || mergeFile.canRead() == false) {
			throw new BuildException("mergePropertyFile " + mergeFile.getAbsolutePath() + " does not exists or cannot be read");
		} else if (mergeFile.length() == 0) {
			log("mergePropertyFile is empty", LogLevel.WARN.getLevel());
		}
		if (mergePropertyFileEncoding == null) {
			mergePropertyFileEncoding = inputPropertyFileEncoding;
		}
		try {
			log("Load merge properties " + mergeFile.getAbsolutePath());
			Reader reader = new BufferedReader(new InputStreamReader(new FileInputStream(mergeFile), mergePropertyFileEncoding));
			if (reader != null) {
				mergeProperties.load(reader);
				reader.close();
			}
			log("Merge properties loaded with " + mergeProperties.size() + " entries");
		} catch (Exception e) {
			throw new BuildException("load inputProperties failed: " + e.getMessage(), e);
		}
		TreeMap<String, String> treeMap = new TreeMap(inputProperties);
		int countUpdatedWithMerge = 0;
		int countAddedFromMerge = 0;
		for (Iterator<Entry<Object, Object>> it = mergeProperties.entrySet().iterator(); it.hasNext(); ) {
			Entry<Object, Object> mergeMapEntry = it.next();
			Object mergeKey = mergeMapEntry.getKey();
			if (treeMap.containsKey(mergeKey)) {
				treeMap.remove(mergeKey);
				if (mergeMapEntry.getValue() != null) {
					treeMap.put(mergeKey.toString(), mergeMapEntry.getValue().toString());
					countUpdatedWithMerge++;
				}
			} else {
				if (mergeMapEntry.getValue() != null) {
					treeMap.put(mergeKey.toString(), mergeMapEntry.getValue().toString());
					countAddedFromMerge++;
				}
			}
		}
		log("Properties merged: " + countAddedFromMerge + " entries added, " + countUpdatedWithMerge + " entries value changed.");
		try {
			if (outputPropertyFile == null || outputPropertyFile.length() == 0) {
				throw new BuildException("outputPropertyFile attribute cannot be null or empty");
			}
			File outputFile = new File(outputPropertyFile);
			if (native2Ascii) {
				outputPropertyFileEncoding = "ASCII";
			} else if (outputPropertyFileEncoding == null) {
				outputPropertyFileEncoding = inputPropertyFileEncoding;
			}
			log("Write output to " + outputFile.getAbsolutePath());
			Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile, false), outputPropertyFileEncoding));
	        for (Entry<String, String> entry: treeMap.entrySet()) {
	        	writer.append(entry.getKey());
	        	writer.append("=");
	        	if (entry.getValue() != null) {
	        		if (native2Ascii) {
			        	writer.append(UnicodeConverter.getStringWithUnicodeLiterals(entry.getValue()));
	        		} else {
			        	writer.append(entry.getValue());
	        		}
	        	}
	        	if ("UNIX".equalsIgnoreCase(outputFileOSType)) {
	        		writer.append("\n");
	        	} else if ("WINDOWS".equalsIgnoreCase(outputFileOSType)) {
	        		writer.append("\r\n");
	        	} else {
	        		writer.append("\n");
	        	}
	        }
	        writer.close();
			log("Output properties sorted and written with " + treeMap.size() + " entries.");
		} catch (Exception e) {
			throw new BuildException("write output failed: " + e.getMessage(), e);
		}
	}

	public String getInputPropertyFile() {
		return inputPropertyFile;
	}

	public void setInputPropertyFile(String inputPropertyFile) {
		this.inputPropertyFile = inputPropertyFile;
	}

	public String getMergePropertyFile() {
		return mergePropertyFile;
	}

	public void setMergePropertyFile(String mergePropertyFile) {
		this.mergePropertyFile = mergePropertyFile;
	}

	public String getOutputPropertyFile() {
		return outputPropertyFile;
	}

	public void setOutputPropertyFile(String outputPropertyFile) {
		this.outputPropertyFile = outputPropertyFile;
	}

	public String getInputPropertyFileEncoding() {
		return inputPropertyFileEncoding;
	}

	public void setInputPropertyFileEncoding(String inputPropertyFileEncoding) {
		this.inputPropertyFileEncoding = inputPropertyFileEncoding;
	}

	public String getMergePropertyFileEncoding() {
		return mergePropertyFileEncoding;
	}

	public void setMergePropertyFileEncoding(String mergePropertyFileEncoding) {
		this.mergePropertyFileEncoding = mergePropertyFileEncoding;
	}

	public String getOutputPropertyFileEncoding() {
		return outputPropertyFileEncoding;
	}

	public void setOutputPropertyFileEncoding(String outputPropertyFileEncoding) {
		this.outputPropertyFileEncoding = outputPropertyFileEncoding;
	}
	
	@Override
	public String getDescription() {
		return "Task to merge two properties and save it as new property file";
	}

	public String getNative2Ascii() {
		return String.valueOf(native2Ascii);
	}

	public void setNative2Ascii(String native2AsciiStr) {
		this.native2Ascii = Boolean.valueOf(native2AsciiStr);
	}
	
}
