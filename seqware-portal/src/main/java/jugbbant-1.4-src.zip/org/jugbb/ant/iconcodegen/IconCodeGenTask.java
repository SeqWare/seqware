package org.jugbb.ant.iconcodegen;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

public class IconCodeGenTask extends Task {

	private String iconPackage = null;
	private String sourceDir = null;
	private String iconFileExtensions = "jpg png gif";
	private String encoding = "UTF-8";
	
	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	public String getIconFileExtensions() {
		return iconFileExtensions;
	}

	public void setIconFileExtensions(String iconFileExtensions) {
		this.iconFileExtensions = iconFileExtensions;
	}

	public String getIconPackage() {
		return iconPackage;
	}

	public void setIconPackage(String iconPackage) {
		this.iconPackage = iconPackage;
	}

	public String getSourceDir() {
		return sourceDir;
	}

	public void setSourceDir(String sourceDir) {
		this.sourceDir = sourceDir;
	}

	@Override
	public void execute() throws BuildException {
		if (sourceDir == null || sourceDir.isEmpty()) {
			throw new BuildException("sourceDir cannot be null or empty");
		}
		if (iconPackage == null || iconPackage.isEmpty()) {
			throw new BuildException("iconPackage cannot be null or empty");
		}
		if (iconFileExtensions == null || iconFileExtensions.isEmpty()) {
			throw new BuildException("iconFileExtensions cannot be null or empty");
		}
		log("creating ApplicationIcons class in src-dir: " + sourceDir + " in package: " + iconPackage + " and use only icon files with extension: " + iconFileExtensions);
		try {
			IconCodeGenerator.createIconProvider(new File(sourceDir), iconPackage, iconFileExtensions, "UTF-8");
			log("Java code successfully created");
		} catch (IOException e) {
			throw new BuildException("failed: " + e.getMessage(), e);
		}
	}

}