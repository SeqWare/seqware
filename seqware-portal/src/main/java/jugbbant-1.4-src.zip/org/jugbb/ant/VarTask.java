package org.jugbb.ant;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

public class VarTask extends Task {

	private String name;
	private String value;
	
	@Override
	public void execute() throws BuildException {
		getProject().setProperty(name, value != null ? value : "");
	}

	@Override
	public String getDescription() {
		return "Set a property value";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
